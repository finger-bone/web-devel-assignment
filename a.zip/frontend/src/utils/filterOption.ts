export const filterOption = (inputValue: string, option: any) => {
  return option.key.includes(inputValue)
}

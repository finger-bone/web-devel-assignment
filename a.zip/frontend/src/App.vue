<script setup lang="ts">
import { App } from 'ant-design-vue'
import { AppProvider } from '@/components/Application'
</script>
<template>
  <App class="h-full">
    <AppProvider />
  </App>
</template>

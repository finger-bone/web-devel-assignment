<template>
  <h1> 欢迎来到后台管理系统! </h1>
</template>

<script lang="ts" setup></script>
